import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini lazily/safely
  const getAiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not configured in environment variables.");
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Software Engineer AI Portfolio Assistant Endpoint
  app.post("/api/assistant", async (req, res) => {
    try {
      const { message, history, developerName, developerRole } = req.body;
      if (!message || typeof message !== "string") {
        return res.status(400).json({ error: "Message is required." });
      }

      const devName = developerName || "Alex Rivera";
      const devRole = developerRole || "Senior Full-Stack Software Engineer";

      const ai = getAiClient();

      const systemInstruction = `You are "Rivera-AI", an intelligent AI career and technical assistant for ${devName}, a ${devRole}.

Background Context:
- Role: Senior Full-Stack Software Engineer & Solutions Architect
- Primary Tech Stack: React 18/19, Node.js, TypeScript, PostgreSQL, Express, Next.js, Docker, AWS (ECS, S3, CloudFront), Redis.
- Key Strengths: System performance tuning, P99 latency reduction, scalable microservices, REST & GraphQL APIs, CI/CD automated pipelines, WCAG AA accessibility, zero-downtime database migrations.
- Featured Projects:
  1. PulseFlow Enterprise Analytics Engine: High-throughput event processing platform (12.5k req/sec, cut latency by 91%).
  2. VaultSync Cloud Document Hub: Direct S3 direct presigned uploads with full-text PostgreSQL GIN search.
  3. DevPipeline CI/CD Observability Portal: Real-time build tracking & SSE webhooks for distributed dev teams.
- Work History: Senior Engineer at Nexus Tech Solutions (99.99% uptime, reduced API latency by 62%), Apex Digital Labs ($4.2M Stripe transactions), Vanguard Software Studios.

Your Tone & Style:
- Professional, confident, clean, and outcomes-focused.
- Highlight clean architecture, scalable problem-solving, quantifiable metrics, and developer experience.
- Keep responses concise (100-200 words) with clean markdown bullet points where appropriate.`;

      let promptText = message;
      if (Array.isArray(history) && history.length > 0) {
        const historyContext = history
          .slice(-6)
          .map((h: { sender: string; text: string }) => `${h.sender === "user" ? "User" : "Rivera-AI"}: ${h.text}`)
          .join("\n");
        promptText = `Previous conversation:\n${historyContext}\n\nUser: ${message}`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: promptText,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      res.json({ reply: response.text || "Thanks for reaching out! Feel free to review the engineering challenge deep-dives or contact me directly for full-stack opportunities." });
    } catch (err: any) {
      console.error("Error in /api/assistant:", err);
      res.status(500).json({
        error: err.message || "An error occurred while generating response.",
        reply: "I am currently running in offline mode. Please feel free to browse my featured projects, tech stack breakdown, or contact me via email!",
      });
    }
  });

  // Project Architecture / Code Solution Deep Dive AI Endpoint
  app.post("/api/explain-architecture", async (req, res) => {
    try {
      const { projectName, problemStatement, technicalSolution, techStack } = req.body;
      const ai = getAiClient();

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: `Provide a high-level senior engineering architectural breakdown for this full-stack project:
Project Name: "${projectName}"
Problem Statement: "${problemStatement}"
Technical Solution: "${technicalSolution}"
Tech Stack: "${Array.isArray(techStack) ? techStack.join(', ') : techStack}"

Format your response in 3 crisp sections:
1. Architectural Flow & Data Pipeline
2. Key Trade-offs & Performance Design Decisions
3. Scalability & High Availability Strategy`,
        config: {
          temperature: 0.5,
        },
      });

      res.json({ explanation: response.text });
    } catch (err: any) {
      console.error("Error explaining architecture:", err);
      res.status(500).json({ error: "Failed to generate architecture breakdown." });
    }
  });

  // Setup Vite in Dev or Static in Production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
