import { DeveloperProfile, TechStackCategory, FeaturedProject, WorkExperience } from '../types';

export const DEFAULT_DEVELOPER_PROFILE: DeveloperProfile = {
  name: "Alex Rivera",
  role: "Senior Full-Stack Software Engineer & Solutions Architect",
  title: "Senior Full-Stack Developer",
  tagline: "Architecting Resilient Distributed Systems & Frictionless Web Interfaces",
  headline: "Building High-Throughput, Sub-Second Applications That Scale Seamlessly.",
  valueProposition: "I design and ship cloud-native full-stack software that connects intuitive React user interfaces with battle-tested Node.js, Express, and PostgreSQL microservices. Passionate about system latency optimization, automated CI/CD pipelines, and high-converting user experiences.",
  ctaTextPrimary: "View Featured Projects",
  ctaTextSecondary: "Get In Touch",
  aboutParagraph1: "With over 5 years of hands-on engineering experience across high-growth tech startups and enterprise platforms, I specialize in engineering full-stack solutions from technical discovery through production deployment. My background combines deep front-end expertise in React and Next.js with robust backend architecture in Node.js, Express, TypeScript, and PostgreSQL. I thrive on translating ambiguous product objectives into clean, well-tested, and scalable software systems.",
  aboutParagraph2: "My core engineering philosophy centers on defensive design, zero-downtime database migrations, and relentless performance tuning. Beyond writing clean code, I am deeply invested in developer experience—establishing automated linting, containerized Docker workflows, and comprehensive integration testing suites. Whether optimizing complex database queries or engineering responsive, accessible design systems, my focus remains steadfast on measurable business outcomes and developer ergonomics.",
  primaryTechStack: ["React", "Node.js", "TypeScript", "PostgreSQL", "Express", "Next.js", "Docker", "AWS"],
  experienceLevel: "Senior (5+ Years Experience)",
  targetAudience: "Tech Recruiters, Engineering Managers & Enterprise Clients",
  email: "alex.rivera.eng@gmail.com",
  location: "San Francisco, CA (Remote Eligible)",
  githubUrl: "https://github.com",
  linkedinUrl: "https://linkedin.com",
  availability: "Available for Senior Full-Stack & Staff Engineering Roles",
  stats: [
    { id: '1', label: 'Production Uptime', value: '99.99%', subtext: 'AWS Cloud Architecture', iconName: 'Activity' },
    { id: '2', label: 'P99 Latency Cut', value: '-62%', subtext: 'Postgres & Redis Caching', iconName: 'Zap' },
    { id: '3', label: 'Active Users Served', value: '1.2M+', subtext: 'Across Distributed APIs', iconName: 'Users' },
    { id: '4', label: 'Codebase Test Coverage', value: '94%', subtext: 'End-to-End & Unit Suites', iconName: 'CheckCircle2' },
  ],
};

export const TECH_STACK_CATEGORIES: TechStackCategory[] = [
  {
    category: 'Frontend',
    icon: 'Layout',
    summary: 'Pixel-perfect, accessible, and high-performance user interfaces built for modern web standards.',
    skills: [
      { name: 'React 18 / 19', level: 'Expert', years: '5 yrs', iconName: 'Code2', description: 'Concurrent mode, custom hooks, state synchronization, and render optimization.', highlight: true },
      { name: 'TypeScript', level: 'Expert', years: '5 yrs', iconName: 'FileCode', description: 'Strict typing, generic abstractions, and server-client shared schemas.', highlight: true },
      { name: 'Next.js (App Router)', level: 'Advanced', years: '3 yrs', iconName: 'Globe', description: 'Server components, SSG/SSR hydration, and edge API route streaming.', highlight: true },
      { name: 'Tailwind CSS', level: 'Expert', years: '4 yrs', iconName: 'Palette', description: 'Custom design systems, responsive grid layouts, and dynamic utility classes.' },
      { name: 'State Management', level: 'Advanced', years: '5 yrs', iconName: 'Layers', description: 'Zustand, Redux Toolkit, React Query / TanStack Query, and Context API.' },
      { name: 'HTML5 & Web Accessibility', level: 'Expert', years: '5+ yrs', iconName: 'CheckCircle', description: 'Semantic markup, WCAG AA compliance, screen reader support, and keyboard nav.' },
    ],
  },
  {
    category: 'Backend',
    icon: 'Server',
    summary: 'Scalable RESTful & GraphQL microservices, authentication, and event-driven architectures.',
    skills: [
      { name: 'Node.js', level: 'Expert', years: '5 yrs', iconName: 'Cpu', description: 'Event loop tuning, async worker threads, and memory profiling.', highlight: true },
      { name: 'Express.js', level: 'Expert', years: '5 yrs', iconName: 'Server', description: 'Custom middleware chains, schema validation, rate limiting, and security headers.', highlight: true },
      { name: 'REST & GraphQL APIs', level: 'Expert', years: '5 yrs', iconName: 'Share2', description: 'API contract design, OpenAPI/Swagger docs, websockets, and rate-limiting.' },
      { name: 'Auth & Security', level: 'Advanced', years: '4 yrs', iconName: 'Shield', description: 'OAuth2, JWT authentication, RBAC, CSRF protection, and bcrypt hashing.' },
      { name: 'Microservices & Queues', level: 'Advanced', years: '3 yrs', iconName: 'Workflow', description: 'BullMQ, Redis queues, pub/sub event emitters, and background job processing.' },
    ],
  },
  {
    category: 'Database & DevOps',
    icon: 'Database',
    summary: 'Relational data modeling, query indexing, containerization, and cloud infrastructure.',
    skills: [
      { name: 'PostgreSQL', level: 'Expert', years: '5 yrs', iconName: 'Database', description: 'Complex JOINs, ACID transactions, B-tree/GIN indexing, and Drizzle/Prisma ORMs.', highlight: true },
      { name: 'Docker & Compose', level: 'Advanced', years: '4 yrs', iconName: 'Box', description: 'Multi-stage builds, minimal image footprints, and local environment parity.', highlight: true },
      { name: 'AWS Cloud', level: 'Advanced', years: '3 yrs', iconName: 'Cloud', description: 'ECS Fargate, S3, RDS PostgreSQL, CloudFront, Lambda, and IAM security policies.', highlight: true },
      { name: 'Redis Caching', level: 'Advanced', years: '4 yrs', iconName: 'Zap', description: 'In-memory caching strategies, cache invalidation, and session storage.' },
      { name: 'CI/CD Pipelines', level: 'Advanced', years: '4 yrs', iconName: 'GitBranch', description: 'GitHub Actions, automated test suites, zero-downtime deployment workflows.' },
    ],
  },
  {
    category: 'Tools & Architecture',
    icon: 'Wrench',
    summary: 'Engineering workflows, developer tooling, system monitoring, and code quality controls.',
    skills: [
      { name: 'Git & GitHub Workflows', level: 'Expert', years: '5+ yrs', iconName: 'GitCommit', description: 'Branching strategies, interactive rebase, code reviews, and semantic release.' },
      { name: 'Jest / Vitest / Playwright', level: 'Advanced', years: '4 yrs', iconName: 'TestTube', description: 'Unit testing, API mock servers (MSW), and cross-browser end-to-end testing.' },
      { name: 'Linux / Bash Scripting', level: 'Advanced', years: '5 yrs', iconName: 'Terminal', description: 'Shell automation, process management, log parsing, and system monitoring.' },
      { name: 'Vite & Webpack', level: 'Advanced', years: '4 yrs', iconName: 'Sliders', description: 'Module bundler configuration, tree-shaking, and asset optimization.' },
    ],
  },
];

export const FEATURED_PROJECTS: FeaturedProject[] = [
  {
    id: 'project-1',
    name: 'PulseFlow Enterprise Analytics Engine',
    tagline: 'Real-time high-throughput event processing platform for e-commerce metrics',
    category: 'Full-Stack',
    problemStatement: 'An e-commerce client was suffering from database locks and 8-second page loads due to unindexed synchronous aggregation queries running directly on their primary PostgreSQL database during peak traffic spikes.',
    technicalSolution: 'Designed a hybrid streaming pipeline with Express and Node.js microservices that ingest user events, push them to a Redis buffer queue, and periodically aggregate metrics into read-heavy materialised PostgreSQL tables exposed via an optimized GraphQL and React dashboard.',
    keyFeatures: [
      'Sub-100ms real-time metric updates using WebSockets and server-sent events.',
      'Dynamic query builder allowing customizable widget layouts and date-range filters.',
      'Role-based access control (RBAC) supporting multi-tenant team workspace isolation.',
      'Export engine supporting background PDF & CSV report generation.'
    ],
    techStack: ['React', 'TypeScript', 'Node.js', 'Express', 'PostgreSQL', 'Redis', 'Docker', 'AWS ECS'],
    engineeringChallenges: [
      {
        challenge: 'Database Lock Contention under 10,000 requests/sec peak traffic.',
        solution: 'Decoupled event ingestion from persistence using Redis stream queues, reducing direct DB writes by 85%.',
        impact: 'Achieved 99.99% ingestion success with zero dropped events during flash sales.'
      },
      {
        challenge: 'Large dataset client-side render lag with over 50,000 DOM elements.',
        solution: 'Implemented virtualized list scrolling (TanStack Virtual) and memoized Canvas charts.',
        impact: 'Render frame rate remained locked at 60 FPS regardless of dataset depth.'
      }
    ],
    metrics: [
      { label: 'Latency Reduction', value: '91% (8s -> 320ms)' },
      { label: 'Throughput', value: '12,500 req/sec' },
      { label: 'DB CPU Usage', value: 'Reduced by 64%' }
    ],
    liveDemoUrl: 'https://example.com/demo1',
    githubUrl: 'https://github.com/example/pulseflow',
    architectureNotes: 'Microservices architecture with Redis pub/sub queue, worker pool, and read-replica PostgreSQL database.',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'project-2',
    name: 'VaultSync Cloud Document Hub',
    tagline: 'Collaborative document management & encryption vault with automated PDF parsing',
    category: 'Cloud & Distributed',
    problemStatement: 'Legal and financial teams needed a secure, searchable document vault that could extract structured metadata from raw multi-page PDFs without storing unencrypted files on third-party cloud servers.',
    technicalSolution: 'Engineered a secure Next.js and Express full-stack application backed by AWS S3 client-side presigned URLs, PostgreSQL full-text search indexing, and a containerized Node.js background worker using PDF-Parse and Tesseract OCR.',
    keyFeatures: [
      'Zero-trust direct client-to-S3 encrypted file uploads bypassing server bottlenecks.',
      'PostgreSQL tsvector full-text search with fuzzy matching and document highlighting.',
      'Interactive document annotation and inline feedback thread system.',
      'Automated background audit logging capturing every file view, edit, and permission change.'
    ],
    techStack: ['Next.js', 'React', 'Node.js', 'Express', 'PostgreSQL', 'AWS S3', 'Docker', 'Tailwind CSS'],
    engineeringChallenges: [
      {
        challenge: 'Server memory exhaustion when processing 200MB+ PDF files simultaneously.',
        solution: 'Offloaded document parsing to isolated Docker container tasks running on AWS ECS with strictly capped memory limits.',
        impact: 'Eliminated main Express API thread freezes and prevented Out-Of-Memory container crashes.'
      },
      {
        challenge: 'Slow text search across 500,000+ extracted PDF text blocks.',
        solution: 'Added GIN indexes on tsvector columns and implemented query trigrams in PostgreSQL.',
        impact: 'Search query turnaround dropped from 2.4 seconds to under 45 milliseconds.'
      }
    ],
    metrics: [
      { label: 'Search Speed', value: '45ms average' },
      { label: 'Upload Efficiency', value: '3x faster via S3 Presigned' },
      { label: 'Security Standard', value: 'SOC2 Compliant Log Audit' }
    ],
    liveDemoUrl: 'https://example.com/demo2',
    githubUrl: 'https://github.com/example/vaultsync',
    architectureNotes: 'Direct browser-to-S3 upload via presigned POST URLs, paired with decoupled ECS worker nodes.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'project-3',
    name: 'DevPipeline CI/CD Observability Portal',
    tagline: 'Unified deployment tracking and developer workflow performance dashboard',
    category: 'DevOps & Pipeline',
    problemStatement: 'Distributed engineering groups lacked visibility into deployment bottlenecks, failing GitHub Actions builds, and cloud infrastructure cost creep across staging and production clusters.',
    technicalSolution: 'Created a developer portal combining React, Express, and PostgreSQL that aggregates build webhooks from GitHub Actions, AWS CloudWatch, and Docker registries into a single unified telemetry interface.',
    keyFeatures: [
      'Webhook listener handling asynchronous build events with HMAC signature verification.',
      'D3.js & Recharts interactive timeline mapping release velocity and build failure trends.',
      'Slack & email alerting integration for failed main-branch deployments.',
      'Infrastructure cost breakdown calculator projecting monthly AWS resource utilization.'
    ],
    techStack: ['React', 'Node.js', 'Express', 'PostgreSQL', 'Docker', 'Tailwind CSS', 'Recharts'],
    engineeringChallenges: [
      {
        challenge: 'Handling out-of-order webhook delivery from concurrent CI build steps.',
        solution: 'Implemented idempotent event processors using state machines and database transaction locks.',
        impact: 'Guaranteed 100% accurate deployment state representation regardless of network jitter.'
      },
      {
        challenge: 'Real-time status updates causing excessive HTTP polling overhead.',
        solution: 'Switched from 2-second HTTP polling to Server-Sent Events (SSE) connections.',
        impact: 'Reduced server network traffic by 78% while providing instant status notifications.'
      }
    ],
    metrics: [
      { label: 'Network Overhead Cut', value: '-78%' },
      { label: 'Build Alert Time', value: '< 1 second' },
      { label: 'Developer Adoption', value: '180+ Engineers' }
    ],
    liveDemoUrl: 'https://example.com/demo3',
    githubUrl: 'https://github.com/example/devpipeline',
    architectureNotes: 'Event-driven Express webhook ingestion service with idempotent SSE stream delivery to React clients.',
    image: 'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?auto=format&fit=crop&w=1200&q=80',
  },
];

export const WORK_EXPERIENCES: WorkExperience[] = [
  {
    id: 'exp-1',
    role: 'Senior Full-Stack Software Engineer',
    company: 'Nexus Tech Solutions Inc.',
    period: '2022 — Present',
    location: 'San Francisco, CA (Hybrid)',
    type: 'Full-time',
    summary: 'Led the core platform team responsible for customer-facing web applications, microservices architecture, and database performance tuning.',
    quantifiableResults: [
      'Architected and executed the migration of a legacy monolithic Express app to modular TypeScript microservices, reducing deployment cycle times from 3 days to under 15 minutes.',
      'Optimized PostgreSQL query execution plans and database indexes, cutting P99 API response latency by 62% across high-frequency customer endpoints.',
      'Mentored 6 junior/mid-level software engineers through bi-weekly code reviews, design docs, and automated testing best practices.',
      'Designed and containerized CI/CD pipelines using Docker and GitHub Actions, achieving 94% test coverage across all core services.'
    ],
    technologies: ['React', 'TypeScript', 'Node.js', 'Express', 'PostgreSQL', 'Docker', 'AWS', 'Tailwind CSS']
  },
  {
    id: 'exp-2',
    role: 'Full-Stack Software Engineer',
    company: 'Apex Digital Labs',
    period: '2020 — 2022',
    location: 'Austin, TX',
    type: 'Full-time',
    summary: 'Developed rich web applications, payment integrations, and real-time dashboard analytics for SaaS clients in fintech and logistics.',
    quantifiableResults: [
      'Built a custom React and Node.js analytics dashboard handling 1.2M+ daily active events with sub-500ms dashboard load speeds.',
      'Integrated Stripe Connect payment processing and subscription billing workflows, generating $4.2M in annual processed volume.',
      'Refactored frontend bundle delivery using code-splitting and asset compression, improving Google Lighthouse Performance score from 58 to 96.'
    ],
    technologies: ['React', 'Node.js', 'Express', 'PostgreSQL', 'Redis', 'REST APIs', 'Jest']
  },
  {
    id: 'exp-3',
    role: 'Software Engineer (Frontend / Full-Stack)',
    company: 'Vanguard Software Studios',
    period: '2019 — 2020',
    location: 'Seattle, WA',
    type: 'Full-time',
    summary: 'Engineered responsive web applications and component design systems for enterprise web clients.',
    quantifiableResults: [
      'Developed a reusable React & Tailwind component library adopted across 8 internal projects, accelerating frontend delivery speed by 40%.',
      'Collaborated closely with UX designers and product managers to deliver WCAG AA accessible user flows for 350,000+ active users.',
      'Implemented automated end-to-end test suites using Cypress and Jest, dropping production regression bug reports by 35%.'
    ],
    technologies: ['JavaScript', 'React', 'HTML5/CSS3', 'Node.js', 'Git', 'REST APIs']
  }
];
