import React, { useState } from 'react';
import { FEATURED_PROJECTS } from '../data/portfolioData';
import { FeaturedProject, EngineeringChallenge } from '../types';
import { 
  Layers, 
  ExternalLink, 
  Github, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Zap, 
  ArrowUpRight, 
  Bot, 
  Loader2, 
  X,
  Code2
} from 'lucide-react';

interface ProjectsSectionProps {
  onOpenAssistantWithTopic: (topic: string) => void;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({ onOpenAssistantWithTopic }) => {
  const [activeProject, setActiveProject] = useState<FeaturedProject | null>(null);
  const [architectureExplanation, setArchitectureExplanation] = useState<string | null>(null);
  const [loadingArch, setLoadingArch] = useState(false);

  const handleExplainArchitecture = async (project: FeaturedProject) => {
    setActiveProject(project);
    setLoadingArch(true);
    setArchitectureExplanation(null);

    try {
      const res = await fetch('/api/explain-architecture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectName: project.name,
          problemStatement: project.problemStatement,
          technicalSolution: project.technicalSolution,
          techStack: project.techStack,
        }),
      });

      const data = await res.json();
      setArchitectureExplanation(data.explanation || 'Architecture breakdown loaded.');
    } catch (err) {
      setArchitectureExplanation('Failed to fetch AI architectural breakdown. Feel free to ask Vance-AI directly!');
    } finally {
      setLoadingArch(false);
    }
  };

  return (
    <section id="projects" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="space-y-2 mb-12">
          <div className="inline-flex items-center space-x-1.5 text-xs font-bold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-md border border-indigo-100">
            <Layers className="w-3.5 h-3.5" />
            <span>Section 04 — Featured Production Systems</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Featured Projects & Engineering Deep-Dives
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
            Real-world full-stack platforms engineered for high throughput, sub-second latency, zero-downtime persistence, and clean maintainable code.
          </p>
        </div>

        {/* Featured Projects Cards Loop */}
        <div className="space-y-12">
          {FEATURED_PROJECTS.map((project, index) => (
            <div
              key={project.id}
              className="bg-slate-50/70 rounded-3xl p-6 sm:p-8 lg:p-10 border border-slate-200 shadow-2xs hover:border-indigo-300 transition-all space-y-8"
            >
              
              {/* Project Title Bar */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-200">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded">
                      0{index + 1} // {project.category}
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    {project.name}
                  </h3>
                  <p className="text-sm font-medium text-slate-600">
                    {project.tagline}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleExplainArchitecture(project)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI Architecture Deep-Dive</span>
                  </button>

                  <button
                    onClick={() => onOpenAssistantWithTopic(`Tell me about the engineering challenges in ${project.name}`)}
                    className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-semibold"
                  >
                    <Bot className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Ask AI</span>
                  </button>
                </div>
              </div>

              {/* Grid Body: Problem & Solution vs Engineering Challenges */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left Side: Problem Statement & Technical Solution (Col 6) */}
                <div className="lg:col-span-6 space-y-6">
                  
                  {/* Problem Statement Box */}
                  <div className="p-5 rounded-2xl bg-rose-50/50 border border-rose-100 space-y-2">
                    <div className="flex items-center space-x-2 text-rose-700 font-bold text-xs uppercase tracking-wider">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span>1. Problem Statement</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-normal">
                      {project.problemStatement}
                    </p>
                  </div>

                  {/* Technical Solution Box */}
                  <div className="p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 space-y-2">
                    <div className="flex items-center space-x-2 text-emerald-800 font-bold text-xs uppercase tracking-wider">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>2. Technical Solution & Key Architecture</span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-normal">
                      {project.technicalSolution}
                    </p>
                  </div>

                  {/* Key Features Bullet List */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Key Features & Capabilities
                    </h4>
                    <ul className="space-y-2">
                      {project.keyFeatures.map((feat, fIdx) => (
                        <li key={fIdx} className="flex items-start space-x-2 text-xs sm:text-sm text-slate-700">
                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Tech Stack Used Tags */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Tech Stack Used
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {project.techStack.map((tech) => (
                        <span
                          key={tech}
                          className="px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-800 font-mono text-xs font-medium shadow-2xs"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                </div>

                {/* Right Side: Key Engineering Challenges & Metrics (Col 6) */}
                <div className="lg:col-span-6 space-y-6">
                  
                  {/* Engineering Challenges List */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 pb-1 border-b border-slate-200">
                      Key Engineering Challenges & How I Solved Them
                    </h4>

                    {project.engineeringChallenges.map((ec, ecIdx) => (
                      <div
                        key={ecIdx}
                        className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-2"
                      >
                        <div className="font-bold text-slate-900 text-xs sm:text-sm text-rose-900 flex items-start space-x-2">
                          <span className="text-rose-600 shrink-0 font-mono">[{ecIdx + 1}]</span>
                          <span>{ec.challenge}</span>
                        </div>

                        <p className="text-xs text-slate-700 leading-relaxed pl-5">
                          <strong className="text-indigo-700 font-semibold">Solution: </strong>
                          {ec.solution}
                        </p>

                        <div className="pl-5 pt-1">
                          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-md bg-indigo-50 border border-indigo-100 text-indigo-700 text-[11px] font-mono font-bold">
                            <Zap className="w-3 h-3 text-indigo-600" />
                            <span>Impact: {ec.impact}</span>
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Measurable Project Metrics */}
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    {project.metrics.map((m, mIdx) => (
                      <div key={mIdx} className="p-3 bg-white rounded-xl border border-slate-200 text-center space-y-0.5">
                        <div className="text-base sm:text-lg font-black text-slate-900">{m.value}</div>
                        <div className="text-[10px] text-slate-500 font-semibold uppercase">{m.label}</div>
                      </div>
                    ))}
                  </div>

                </div>

              </div>

            </div>
          ))}
        </div>

      </div>

      {/* AI Architecture Deep-Dive Modal */}
      {activeProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">
                    Architectural Deep Dive: {activeProject.name}
                  </h3>
                  <p className="text-xs text-emerald-600 font-semibold">
                    Generated via Gemini AI Systems Analysis
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActiveProject(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {loadingArch ? (
              <div className="py-12 flex flex-col items-center justify-center space-y-3 text-indigo-600">
                <Loader2 className="w-8 h-8 animate-spin" />
                <span className="text-xs font-bold">Formulating system trade-offs & pipeline breakdown...</span>
              </div>
            ) : (
              <div className="prose prose-slate prose-sm max-w-none text-slate-800 space-y-4 whitespace-pre-wrap leading-relaxed text-xs sm:text-sm">
                {architectureExplanation}
              </div>
            )}

            <div className="pt-4 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setActiveProject(null)}
                className="px-5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
              >
                Close Breakdown
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
