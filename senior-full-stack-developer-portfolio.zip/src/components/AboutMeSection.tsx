import React from 'react';
import { DeveloperProfile } from '../types';
import { CheckCircle2, ShieldCheck, Cpu, GitPullRequest, Code2, Sparkles, Terminal } from 'lucide-react';

interface AboutMeSectionProps {
  profile: DeveloperProfile;
}

export const AboutMeSection: React.FC<AboutMeSectionProps> = ({ profile }) => {
  const pillars = [
    {
      title: 'Defensive Engineering & Resilience',
      desc: 'Designing systems with graceful degradation, circuit breakers, and comprehensive rate-limiting to ensure high availability.',
      icon: ShieldCheck,
    },
    {
      title: 'Database & Latency Optimization',
      desc: 'Crafting explicit PostgreSQL queries, indexing patterns, and Redis caching layers that maintain sub-100ms response times under load.',
      icon: Cpu,
    },
    {
      title: 'Developer Ergonomics & CI/CD',
      desc: 'Establishing strict TypeScript contracts, Dockerized local setups, and automated GitHub Actions pipelines with 90%+ test coverage.',
      icon: GitPullRequest,
    },
  ];

  return (
    <section id="about" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 text-xs font-bold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-md border border-indigo-100">
              <Code2 className="w-3.5 h-3.5" />
              <span>Section 02 — Engineering Identity</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              About Me & Engineering Mindset
            </h2>
          </div>

          <div className="text-xs font-mono bg-slate-100 text-slate-600 px-3.5 py-1.5 rounded-lg border border-slate-200 self-start md:self-auto">
            Target Audience: {profile.targetAudience}
          </div>
        </div>

        {/* 2-Paragraph Summary Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: 2 Concise Paragraphs (Col 7) */}
          <div className="lg:col-span-7 space-y-6 text-slate-700 leading-relaxed text-base">
            
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 shadow-2xs space-y-4">
              <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
                <Terminal className="w-4 h-4" />
                <span>Background & Architecture Focus</span>
              </div>
              <p className="text-sm sm:text-base leading-relaxed text-slate-700">
                {profile.aboutParagraph1}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 shadow-2xs space-y-4">
              <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
                <Sparkles className="w-4 h-4" />
                <span>Problem-Solving Mindset & Quality Standard</span>
              </div>
              <p className="text-sm sm:text-base leading-relaxed text-slate-700">
                {profile.aboutParagraph2}
              </p>
            </div>

          </div>

          {/* Right Column: Core Engineering Pillars (Col 5) */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 pb-1 border-b border-slate-200">
              Core Engineering Pillars
            </h3>

            {pillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-indigo-300 hover:shadow-md transition-all space-y-2 group"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <h4 className="font-bold text-slate-900 text-sm">
                      {pillar.title}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed pl-12">
                    {pillar.desc}
                  </p>
                </div>
              );
            })}

          </div>

        </div>

      </div>
    </section>
  );
};
