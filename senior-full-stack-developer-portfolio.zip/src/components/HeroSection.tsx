import React from 'react';
import { DeveloperProfile } from '../types';
import { 
  ArrowRight, 
  Mail, 
  FileText, 
  Sparkles, 
  Activity, 
  Zap, 
  Users, 
  CheckCircle2, 
  Github, 
  Linkedin,
  MapPin,
  Code2,
  Terminal,
  Server,
  Database
} from 'lucide-react';

interface HeroSectionProps {
  profile: DeveloperProfile;
  onOpenAssistant: () => void;
  onOpenResume: () => void;
  onExploreProjects: () => void;
  onContactClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  profile,
  onOpenAssistant,
  onOpenResume,
  onExploreProjects,
  onContactClick,
}) => {
  return (
    <section id="overview" className="relative pt-8 sm:pt-14 pb-16 bg-gradient-to-b from-slate-50 via-white to-slate-50 border-b border-slate-200 overflow-hidden">
      
      {/* Subtle Background Accent Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Availability & Target Audience Badge */}
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200/80 text-emerald-800 text-xs font-bold shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
            <span>{profile.availability}</span>
          </div>

          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
            <MapPin className="w-3.5 h-3.5 text-indigo-600" />
            <span>{profile.location}</span>
          </div>
        </div>

        {/* Hero Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Main Hero Copy (Col 7) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Developer Title Tag */}
            <div className="space-y-1">
              <span className="text-xs font-extrabold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md border border-indigo-100">
                {profile.role}
              </span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.12] pt-2">
                {profile.headline}
              </h1>
            </div>

            {/* 2-Sentence Value Proposition */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl font-normal">
              {profile.valueProposition}
            </p>

            {/* Primary Tech Stack Badge Row */}
            <div className="space-y-2 pt-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
                Primary Core Stack
              </span>
              <div className="flex flex-wrap gap-1.5">
                {profile.primaryTechStack.map((tech) => (
                  <span
                    key={tech}
                    className="px-2.5 py-1 rounded-md bg-slate-900 text-white text-xs font-mono font-medium shadow-2xs hover:bg-indigo-600 transition-colors"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Action CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <button
                onClick={onExploreProjects}
                className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold shadow-md hover:shadow-indigo-200 transition-all transform hover:-translate-y-0.5"
              >
                <span>{profile.ctaTextPrimary}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onContactClick}
                className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-900 border border-slate-300 text-sm font-bold shadow-xs transition-all"
              >
                <Mail className="w-4 h-4 text-indigo-600" />
                <span>{profile.ctaTextSecondary}</span>
              </button>

              <button
                onClick={onOpenResume}
                className="flex items-center space-x-1.5 px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
              >
                <FileText className="w-4 h-4 text-slate-600" />
                <span>Download CV</span>
              </button>
            </div>

          </div>

          {/* Right Column: Code Architecture Preview Card (Col 5) */}
          <div className="lg:col-span-5">
            <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 shadow-2xl border border-slate-800 space-y-4 relative">
              
              {/* Window Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500" />
                  <div className="w-3 h-3 rounded-full bg-amber-500" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  <span className="text-xs font-mono text-slate-400 pl-2">architecture.config.ts</span>
                </div>
                <span className="text-[10px] font-mono bg-indigo-900/80 text-indigo-300 px-2 py-0.5 rounded">
                  Full-Stack Schema
                </span>
              </div>

              {/* Code Snippet Box */}
              <pre className="font-mono text-xs leading-relaxed text-slate-300 overflow-x-auto p-3 bg-slate-950/80 rounded-xl border border-slate-800/80">
                <code>
<span className="text-indigo-400">export const</span> <span className="text-amber-300">stackArchitecture</span> = &#123;{'\n'}
{'  '}<span className="text-slate-400">// Client Layer</span>{'\n'}
{'  '}frontend: [<span className="text-emerald-300">'React 18'</span>, <span className="text-emerald-300">'TypeScript'</span>, <span className="text-emerald-300">'Next.js'</span>],{'\n'}
{'  '}<span className="text-slate-400">// Server & Microservices</span>{'\n'}
{'  '}backend: [<span className="text-emerald-300">'Node.js'</span>, <span className="text-emerald-300">'Express'</span>, <span className="text-emerald-300">'Redis'</span>],{'\n'}
{'  '}<span className="text-slate-400">// Persistence & Infrastructure</span>{'\n'}
{'  '}database: <span className="text-emerald-300">'PostgreSQL (Indexing & ACID)'</span>,{'\n'}
{'  '}devops: [<span className="text-emerald-300">'Docker'</span>, <span className="text-emerald-300">'AWS ECS Fargate'</span>, <span className="text-emerald-300">'S3'</span>],{'\n'}
{'  '}outcomes: &#123;{'\n'}
{'    '}p99Latency: <span className="text-rose-300">'&lt; 150ms'</span>,{'\n'}
{'    '}uptimeTarget: <span className="text-emerald-300">'99.99%'</span>,{'\n'}
{'    '}ciCdPipeline: <span className="text-amber-300">'Automated GitHub Actions'</span>{'\n'}
{'  '}&#125;{'\n'}
&#125;;
                </code>
              </pre>

              {/* Quick AI Trigger Banner inside Hero */}
              <div className="p-3 bg-indigo-950/60 rounded-xl border border-indigo-800/60 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
                  <p className="text-xs text-indigo-200">Have specific technical or hiring questions?</p>
                </div>
                <button
                  onClick={onOpenAssistant}
                  className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold shrink-0 transition-colors"
                >
                  Ask AI
                </button>
              </div>

            </div>
          </div>

        </div>

        {/* Quantifiable Metrics Strip */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          {profile.stats.map((stat) => (
            <div
              key={stat.id}
              className="bg-white rounded-xl p-5 border border-slate-200/80 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all space-y-1 group"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-slate-500">
                  {stat.label}
                </span>
                <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  <Zap className="w-4 h-4" />
                </div>
              </div>

              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {stat.value}
              </div>

              <p className="text-xs text-slate-500 font-medium">
                {stat.subtext}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
