import React, { useState } from 'react';
import { TECH_STACK_CATEGORIES } from '../data/portfolioData';
import { 
  Layout, 
  Server, 
  Database, 
  Wrench, 
  Code2, 
  FileCode, 
  Globe, 
  Palette, 
  Layers, 
  CheckCircle, 
  Cpu, 
  Share2, 
  Shield, 
  Workflow, 
  Box, 
  Cloud, 
  Zap, 
  GitBranch, 
  GitCommit, 
  TestTube, 
  Terminal, 
  Sliders,
  Check
} from 'lucide-react';

export const TechStackSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Icon map lookup helper
  const renderIcon = (name: string) => {
    switch (name) {
      case 'Code2': return <Code2 className="w-4 h-4" />;
      case 'FileCode': return <FileCode className="w-4 h-4" />;
      case 'Globe': return <Globe className="w-4 h-4" />;
      case 'Palette': return <Palette className="w-4 h-4" />;
      case 'Layers': return <Layers className="w-4 h-4" />;
      case 'Cpu': return <Cpu className="w-4 h-4" />;
      case 'Server': return <Server className="w-4 h-4" />;
      case 'Share2': return <Share2 className="w-4 h-4" />;
      case 'Shield': return <Shield className="w-4 h-4" />;
      case 'Workflow': return <Workflow className="w-4 h-4" />;
      case 'Database': return <Database className="w-4 h-4" />;
      case 'Box': return <Box className="w-4 h-4" />;
      case 'Cloud': return <Cloud className="w-4 h-4" />;
      case 'Zap': return <Zap className="w-4 h-4" />;
      case 'GitBranch': return <GitBranch className="w-4 h-4" />;
      case 'GitCommit': return <GitCommit className="w-4 h-4" />;
      case 'TestTube': return <TestTube className="w-4 h-4" />;
      case 'Terminal': return <Terminal className="w-4 h-4" />;
      default: return <CheckCircle className="w-4 h-4" />;
    }
  };

  const categories = ['All', 'Frontend', 'Backend', 'Database & DevOps', 'Tools & Architecture'];

  const filteredCategories = selectedCategory === 'All'
    ? TECH_STACK_CATEGORIES
    : TECH_STACK_CATEGORIES.filter((c) => c.category === selectedCategory);

  return (
    <section id="techstack" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 text-xs font-bold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-md border border-indigo-100">
              <Server className="w-3.5 h-3.5" />
              <span>Section 03 — Technical Capabilities</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Tech Stack & Skill Breakdown
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
              Logically categorized technologies across frontend engineering, backend microservices, database optimization, and cloud infrastructure.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1.5 bg-white p-1.5 rounded-xl border border-slate-200">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedCategory === cat
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Tech Stack Cards Grid */}
        <div className="space-y-8">
          {filteredCategories.map((group) => (
            <div
              key={group.category}
              className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6"
            >
              {/* Category Title Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
                    {group.category === 'Frontend' && <Layout className="w-5 h-5" />}
                    {group.category === 'Backend' && <Server className="w-5 h-5" />}
                    {group.category === 'Database & DevOps' && <Database className="w-5 h-5" />}
                    {group.category === 'Tools & Architecture' && <Wrench className="w-5 h-5" />}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">{group.category}</h3>
                    <p className="text-xs text-slate-500 font-medium">{group.summary}</p>
                  </div>
                </div>

                <span className="text-xs font-mono font-bold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
                  {group.skills.length} Technologies
                </span>
              </div>

              {/* Skill Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {group.skills.map((skill) => (
                  <div
                    key={skill.name}
                    className={`p-4 rounded-xl border transition-all ${
                      skill.highlight
                        ? 'bg-indigo-50/40 border-indigo-200 hover:border-indigo-400'
                        : 'bg-slate-50/60 border-slate-200/80 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <div className={`p-1.5 rounded-lg ${skill.highlight ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'}`}>
                          {renderIcon(skill.iconName)}
                        </div>
                        <span className="font-bold text-slate-900 text-sm">{skill.name}</span>
                      </div>

                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
                          {skill.level}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 bg-slate-200/70 px-1.5 py-0.5 rounded">
                          {skill.years}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {skill.description}
                    </p>
                  </div>
                ))}
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
