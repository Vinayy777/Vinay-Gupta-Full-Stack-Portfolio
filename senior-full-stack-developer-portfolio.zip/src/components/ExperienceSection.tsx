import React from 'react';
import { WORK_EXPERIENCES } from '../data/portfolioData';
import { Briefcase, Calendar, MapPin, CheckCircle2, TrendingUp, Award, Layers } from 'lucide-react';

export const ExperienceSection: React.FC = () => {
  return (
    <section id="experience" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="space-y-2 mb-12">
          <div className="inline-flex items-center space-x-1.5 text-xs font-bold uppercase tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-md border border-indigo-100">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Section 05 — Career Outcomes & Scale</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Work History & Quantifiable Impact
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
            A track record of driving system stability, reducing API latencies, scaling web platforms, and mentoring engineering teams.
          </p>
        </div>

        {/* Experience Timeline Loop */}
        <div className="space-y-8 relative before:absolute before:inset-0 before:left-4 sm:before:left-8 before:w-0.5 before:bg-slate-200">
          {WORK_EXPERIENCES.map((exp, idx) => (
            <div key={exp.id} className="relative pl-10 sm:pl-16 group">
              
              {/* Timeline Dot */}
              <div className="absolute left-2.5 sm:left-6 top-1.5 -translate-x-1/2 w-4 h-4 rounded-full bg-white border-4 border-indigo-600 group-hover:scale-125 transition-transform" />

              {/* Main Card */}
              <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-2xs hover:border-indigo-300 transition-all space-y-4">
                
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div>
                    <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">
                      {exp.role}
                    </h3>
                    <div className="text-sm font-bold text-indigo-700">
                      {exp.company}
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 text-xs font-mono text-slate-500">
                    <span className="flex items-center space-x-1 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{exp.period}</span>
                    </span>
                    <span className="flex items-center space-x-1 bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{exp.location}</span>
                    </span>
                  </div>
                </div>

                {/* Role High-Level Summary */}
                <p className="text-xs sm:text-sm text-slate-700 font-medium">
                  {exp.summary}
                </p>

                {/* Quantifiable Bullet Points with Action Verbs */}
                <div className="space-y-2 pt-2">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 flex items-center space-x-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Quantifiable Accomplishments & Scale</span>
                  </h4>

                  <ul className="space-y-2.5">
                    {exp.quantifiableResults.map((result, rIdx) => (
                      <li key={rIdx} className="flex items-start space-x-3 text-xs sm:text-sm text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{result}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies Badge Row */}
                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1">
                    Stack:
                  </span>
                  {exp.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[11px] font-semibold border border-slate-200/60"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
