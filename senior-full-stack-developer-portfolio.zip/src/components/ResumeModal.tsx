import React from 'react';
import { DeveloperProfile } from '../types';
import { WORK_EXPERIENCES, FEATURED_PROJECTS } from '../data/portfolioData';
import { X, Printer, Download, Mail, MapPin, Globe, CheckCircle2, Award } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: DeveloperProfile;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, profile }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full p-6 sm:p-10 shadow-2xl border border-slate-200 relative my-8 text-slate-800">
        
        {/* Action Header (Hidden during print) */}
        <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-200 print:hidden">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-widest text-indigo-700 bg-indigo-50 px-3 py-1 rounded-md border border-indigo-100">
              Curriculum Vitae / Resume
            </span>
            <span className="text-xs text-slate-500 font-medium hidden sm:inline">
              Ready for Print & PDF Export
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Resume Sheet Document Body */}
        <div className="space-y-6 font-sans text-xs sm:text-sm">
          
          {/* Header Identity */}
          <div className="border-b border-slate-300 pb-4 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 uppercase tracking-tight">
                {profile.name}
              </h1>
              <p className="text-sm font-bold text-indigo-700">
                {profile.role}
              </p>
            </div>

            <div className="text-left sm:text-right text-xs space-y-1 font-mono text-slate-600">
              <div className="flex items-center sm:justify-end space-x-1">
                <Mail className="w-3.5 h-3.5 text-indigo-600" />
                <span>{profile.email}</span>
              </div>
              <div className="flex items-center sm:justify-end space-x-1">
                <MapPin className="w-3.5 h-3.5 text-indigo-600" />
                <span>{profile.location}</span>
              </div>
            </div>
          </div>

          {/* Professional Summary */}
          <div className="space-y-1.5">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              Executive Summary
            </h2>
            <p className="text-xs text-slate-700 leading-relaxed">
              {profile.aboutParagraph1}
            </p>
          </div>

          {/* Core Tech Stack */}
          <div className="space-y-1.5">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              Core Technical Competencies
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div>
                <strong className="text-slate-900">Languages & Frameworks:</strong> React 18/19, TypeScript, Next.js, Node.js, Express, HTML5, Tailwind CSS
              </div>
              <div>
                <strong className="text-slate-900">Data & DevOps:</strong> PostgreSQL, Redis, Docker, AWS (ECS, S3, CloudFront), REST/GraphQL, CI/CD
              </div>
            </div>
          </div>

          {/* Work Experience */}
          <div className="space-y-4">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              Work History & Achievements
            </h2>

            {WORK_EXPERIENCES.map((exp) => (
              <div key={exp.id} className="space-y-1.5">
                <div className="flex items-center justify-between font-bold text-slate-900 text-xs sm:text-sm">
                  <span>{exp.role} — <span className="text-indigo-700">{exp.company}</span></span>
                  <span className="font-mono text-[11px] text-slate-500">{exp.period} | {exp.location}</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-xs text-slate-700">
                  {exp.quantifiableResults.map((res, idx) => (
                    <li key={idx}>{res}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Featured Production Systems */}
          <div className="space-y-3">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
              Featured Production Systems
            </h2>

            {FEATURED_PROJECTS.slice(0, 2).map((proj) => (
              <div key={proj.id} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                  <span>{proj.name} ({proj.techStack.join(', ')})</span>
                </div>
                <p className="text-xs text-slate-700">
                  <strong>Solution:</strong> {proj.technicalSolution}
                </p>
              </div>
            ))}
          </div>

        </div>

        {/* Footer */}
        <div className="pt-6 mt-6 border-t border-slate-200 text-center text-[10px] text-slate-400 font-mono print:hidden">
          Generated from {profile.name}'s Interactive Full-Stack Engineering Portfolio.
        </div>

      </div>
    </div>
  );
};
