import React, { useState, useEffect } from 'react';
import { DEFAULT_DEVELOPER_PROFILE } from './data/portfolioData';
import { DeveloperProfile } from './types';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutMeSection } from './components/AboutMeSection';
import { TechStackSection } from './components/TechStackSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ExperienceSection } from './components/ExperienceSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { AssistantDrawer } from './components/AssistantDrawer';
import { ResumeModal } from './components/ResumeModal';
import { CustomizeProfileModal } from './components/CustomizeProfileModal';

export default function App() {
  const [activeSection, setActiveSection] = useState('overview');
  
  // Profile state with localStorage persistence
  const [profile, setProfile] = useState<DeveloperProfile>(() => {
    try {
      const saved = localStorage.getItem('developer_profile_custom');
      return saved ? JSON.parse(saved) : DEFAULT_DEVELOPER_PROFILE;
    } catch (e) {
      return DEFAULT_DEVELOPER_PROFILE;
    }
  });

  // Modal States
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantInitialTopic, setAssistantInitialTopic] = useState<string | undefined>(undefined);
  const [resumeOpen, setResumeOpen] = useState(false);
  const [customizeOpen, setCustomizeOpen] = useState(false);

  const handleUpdateProfile = (newProfile: DeveloperProfile) => {
    setProfile(newProfile);
    try {
      localStorage.setItem('developer_profile_custom', JSON.stringify(newProfile));
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  };

  const handleResetProfile = () => {
    setProfile(DEFAULT_DEVELOPER_PROFILE);
    try {
      localStorage.removeItem('developer_profile_custom');
    } catch (e) {
      console.error('Failed to remove from localStorage', e);
    }
  };

  const handleOpenAssistantWithTopic = (topic: string) => {
    setAssistantInitialTopic(topic);
    setAssistantOpen(true);
  };

  const handleExploreProjects = () => {
    setActiveSection('projects');
    const el = document.getElementById('projects');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleContactClick = () => {
    setActiveSection('contact');
    const el = document.getElementById('contact');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      
      {/* Top Header Navbar */}
      <Navbar
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        profile={profile}
        onOpenAssistant={() => {
          setAssistantInitialTopic(undefined);
          setAssistantOpen(true);
        }}
        onOpenResume={() => setResumeOpen(true)}
        onOpenCustomize={() => setCustomizeOpen(true)}
      />

      {/* 1. Hero Section */}
      <HeroSection
        profile={profile}
        onOpenAssistant={() => {
          setAssistantInitialTopic(undefined);
          setAssistantOpen(true);
        }}
        onOpenResume={() => setResumeOpen(true)}
        onExploreProjects={handleExploreProjects}
        onContactClick={handleContactClick}
      />

      {/* 2. About Me Section */}
      <AboutMeSection profile={profile} />

      {/* 3. Tech Stack Breakdown */}
      <TechStackSection />

      {/* 4. Featured Production Projects */}
      <ProjectsSection
        onOpenAssistantWithTopic={handleOpenAssistantWithTopic}
      />

      {/* 5. Work Experience & History */}
      <ExperienceSection />

      {/* 6. Contact Section */}
      <ContactSection
        profile={profile}
        onOpenAssistant={() => {
          setAssistantInitialTopic(undefined);
          setAssistantOpen(true);
        }}
      />

      {/* Footer */}
      <Footer
        profile={profile}
        setActiveSection={setActiveSection}
      />

      {/* AI Career & Architecture Assistant Drawer */}
      <AssistantDrawer
        isOpen={assistantOpen}
        onClose={() => setAssistantOpen(false)}
        profile={profile}
        initialTopic={assistantInitialTopic}
      />

      {/* Curriculum Vitae / Resume Modal */}
      <ResumeModal
        isOpen={resumeOpen}
        onClose={() => setResumeOpen(false)}
        profile={profile}
      />

      {/* Profile Customization Modal */}
      <CustomizeProfileModal
        isOpen={customizeOpen}
        onClose={() => setCustomizeOpen(false)}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
        onResetProfile={handleResetProfile}
      />

    </div>
  );
}
